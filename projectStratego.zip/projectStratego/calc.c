#include "common.h"
#include "main.h"
#include "calc.h"
#include "render.h"

void calcBox(mouse *tha_mouse) {
  // Get The Correct Location //
  for (int a = 0; a < MAX_BOXES_Y; a++) {
    for (int b = 0; b < MAX_BOXES_X; b++) {
      int index = ((MAX_BOXES_Y * a) + b);
      box theBox = boxes[index];

      if (tha_mouse->x >= theBox.x_box && tha_mouse->x <= theBox.x_box + 100) {
        if (tha_mouse->y >= theBox.y_box && tha_mouse->y <= theBox.y_box + 100) {
          tha_now_box.id_box = theBox.id_box;

          blit(load_texture("gfx/reticle.png"), theBox.x_box + 50, theBox.y_box + 50, 1);
        }
      }
    }
  }
}

