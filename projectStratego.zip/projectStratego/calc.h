#ifndef CALC_H
#define CALC_H

void calcBox(mouse *tha_mouse); // Update tha_now_box //

#endif