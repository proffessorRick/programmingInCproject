  /////////////////////////////////////////
  // There Will Be A Few Trough The Game //
  // Those Loops Are:                    //
  // 1: Build The Game                   //
  // 2: Set All Pieces On The Board      //
  // 3: Play The Game                    //
  /////////////////////////////////////////
