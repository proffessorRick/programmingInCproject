#ifndef LOAD_H
#define LOAD_H

void loadMove();

void loadDisplay();
void loadSelectedDisplay(box *selectedBox);

void loadTeamShower();

void loadPieces();
void loadGrid();

// Get Box //
box getBox(box *selectedBox);

#endif