#ifndef main_h
#define main_h

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// THE GLOBALS /////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
extern SDL_Window *window;
extern SDL_Renderer *renderer;
extern mouse mousepointer;

extern currentBox tha_now_box;
extern box selectedBoxA;
extern box selectedBoxB;

extern int pieceCounter, teamCounter, selectedPiece, gamePhase, selectionCounter;
extern int losses[2]; // index 0 is blue and 1 is red //


extern struct _box_ boxes[150];
extern struct _piece_ piecesBlue[PIECES_PER_TEAM];
extern struct _piece_ piecesRed[PIECES_PER_TEAM];

extern char *textBlue[12];
extern char *textRed[12];

#endif
