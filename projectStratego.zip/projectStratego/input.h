#ifndef INPUT_H
#define INPUT_H

void process_input(mouse *tha_mouse); // For All Input //
void proper_shutdown(void); // For Shuting Down SDL //

#endif