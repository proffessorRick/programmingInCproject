////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// THE LIBRARIES ///////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include "common.h"
#include "main.h"
#include "input.h"
#include "load.h"
#include "init.h"
#include "render.h"
#include "calc.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// THE GLOBALS /////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
SDL_Window *window = NULL;
SDL_Renderer *renderer = NULL;

mouse mousepointer;

currentBox tha_now_box;
box selectedBoxA, selectedBoxB;

int pieceCounter, teamCounter, selectedPiece, gamePhase, selectionCounter;
int losses[2] = { 0, 0 }; // index 0 is blue and 1 is red //

struct _box_ boxes[150];
struct _piece_ piecesBlue[PIECES_PER_TEAM];
struct _piece_ piecesRed[PIECES_PER_TEAM];

char *textBlue[12] = {
  "gfx/pieces/blue/maarschalkBlue.png", "gfx/pieces/blue/generaalBlue.png",
  "gfx/pieces/blue/kolonelBlue.png",    "gfx/pieces/blue/majoorBlue.png",
  "gfx/pieces/blue/kapiteinBlue.png",   "gfx/pieces/blue/luitenantBlue.png",
  "gfx/pieces/blue/sergeantBlue.png",   "gfx/pieces/blue/mineurBlue.png",
  "gfx/pieces/blue/verkennerBlue.png",  "gfx/pieces/blue/spionBlue.png",
  "gfx/pieces/blue/vlagBlue.png",       "gfx/pieces/blue/bomBlue.png"
};
char *textRed[12] = {
  "gfx/pieces/red/maarschalkRed.png",   "gfx/pieces/red/generaalRed.png",
  "gfx/pieces/red/kolonelRed.png",      "gfx/pieces/red/majoorRed.png",
  "gfx/pieces/red/kapiteinRed.png",     "gfx/pieces/red/luitenantRed.png",
  "gfx/pieces/red/sergeantRed.png",     "gfx/pieces/red/mineurRed.png",
  "gfx/pieces/red/verkennerRed.png",    "gfx/pieces/red/spionRed.png",
  "gfx/pieces/red/vlagRed.png",         "gfx/pieces/red/bomRed.png"
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// THE MAIN ////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int main(int argc, char *argv[]) {
  //////////////////////////////////
  // Start Step 1: Build The Game //
  //////////////////////////////////
  initSDL(argc, argv); // Set Everything Up //
  initGrid();          // Make The Grid For The Game //

  ///////////////////////////////////////////////
  // Start Step 2: Set All Pieces On The Board //
  ///////////////////////////////////////////////
  gamePhase = 2;
  for (pieceCounter = 0; pieceCounter < PIECES_PER_TEAM; pieceCounter++) {
    for (teamCounter = 0; teamCounter < 2; teamCounter++) {
      while (1) {
        // Re-render Screen //
        SDL_SetRenderDrawColor(renderer, 120, 144, 156, 255);   
        SDL_RenderClear(renderer);

        // Load Everything //
        loadGrid();
        loadDisplay();
        loadPieces();

        // Show What Box Player Is In //
        calcBox(&mousepointer);

        // Process All Actions Player Does (mouse presses or keyboard presses) //
        process_input(&mousepointer);
        
        SDL_RenderPresent(renderer);
        SDL_Delay(16);

        // Break Out Of Infinite Loop If A New Piece Has Been Set //
        if (teamCounter == 0 && piecesBlue[pieceCounter].alive_piece == 1) break;
        if (teamCounter == 1 && piecesRed[pieceCounter].alive_piece == 1) break;
      }    
    }
  }

  /////////////////////////////////
  // Start Step 3: Play The Game //
  /////////////////////////////////
  gamePhase = 3;
  while (1) {
    for (teamCounter = 0; teamCounter < 2; teamCounter++) {
      while (1) {
        // Re-render Screen //
        SDL_SetRenderDrawColor(renderer, 120, 144, 156, 255);   
        SDL_RenderClear(renderer);

        // Load Everything //
        loadGrid();
        if (selectionCounter == 1) {
          loadSelectedDisplay(&selectedBoxA);
        }

        loadPieces();

        // Show What Box Player Is In //
        calcBox(&mousepointer);

        // Process All Actions Player Does (mouse presses or keyboard presses) //
        process_input(&mousepointer);

        // Compare Boxes //
        if (selectionCounter == 2) {
          loadMove();
        }

        loadTeamShower();

        SDL_RenderPresent(renderer);
        SDL_Delay(16);      

        // If Either Side Lost Too Much //
        if (losses[0] == PIECES_PER_TEAM || losses[1] == PIECES_PER_TEAM) {
          // Start Step 4: Determine The Winner
          proper_shutdown();
          return 0;
        }
      }
    }
  }
}