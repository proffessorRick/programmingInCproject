#include "common.h"
#include "main.h"
#include "render.h"

void blit(SDL_Texture *txtr, int x, int y, int center) {
  SDL_Rect dest;
  dest.x = x;
  dest.y = y;

  SDL_QueryTexture(txtr, NULL, NULL, &dest.w, &dest.h);

  // If center != 0, render texture with its center on (x,y), NOT
  // with its top-left corner...
  if (center) {
    dest.x -= dest.w / 2;
    dest.y -= dest.h / 2;
  }

  SDL_RenderCopy(renderer, txtr, NULL, &dest);
}

SDL_Texture *load_texture(char *filename) {
  SDL_Texture *txtr;
  txtr = IMG_LoadTexture(renderer, filename);
  return txtr;
}

