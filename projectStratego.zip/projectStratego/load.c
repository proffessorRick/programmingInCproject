#include "common.h"
#include "main.h"
#include "load.h"
#include "render.h"

void loadMove() {
  box startBox = getBox(&selectedBoxA);
  box endBox   = getBox(&selectedBoxB);

  // Check If endBox Is Empty: Then It Can Just Move In //
  if (endBox.state_box == FREE) {
    // Overwrite The Endbox With The StartBox //
    endBox.id_piece  = startBox.id_piece;
    endBox.state_box = startBox.state_box;

    // Set Startbox To Empty //
    startBox.state_box = FREE;
    startBox.id_piece  = 200;

    // Reset It To Zero //
    selectionCounter = 0;

    // Save Box //
    for (int a = 0; a < MAX_BOXES_Y + 1; a++) { // The Location For Y //
      for (int b = 0; b < MAX_BOXES_X + 1; b++) { // The Location For X //
        int index = ((MAX_BOXES_Y * a) + b);
        box theBox = boxes[index];

        if (theBox.id_box == startBox.id_box) boxes[index] = startBox;
        if (theBox.id_box == endBox.id_box) boxes[index]   = endBox;
      }
    }

    if (teamCounter == 0) {
      teamCounter++;
    }
    else if (teamCounter == 1) {
      teamCounter--;
    }
  } 

  else if (endBox.state_box != FREE) { // Someones Here... //
    if (teamCounter == 0 && endBox.state_box == OCCUPIED_RED) { // Battle Time
      piece attackingPiece = piecesBlue[startBox.id_piece];
      piece defendingPiece = piecesRed[endBox.id_piece];

      int rankA = attackingPiece.rank_piece;
      int rankB = defendingPiece.rank_piece;

      // Determine Higer Rank //
      if (rankA == rankB) { // BOTH LOSE //
        attackingPiece.alive_piece = 0;
        startBox.state_box = FREE;

        defendingPiece.alive_piece = 0;
        endBox.state_box = FREE;

        selectionCounter = 0;

        losses[0] = losses[0] + 1;
        losses[1] = losses[1] + 1;
      }
      else if (rankB == 11 && rankA != 7) { // BOMB BLOWS U UP
        attackingPiece.alive_piece = 0;
        startBox.state_box = FREE;

        defendingPiece.alive_piece = 0;
        endBox.state_box = FREE;

        selectionCounter = 0;

        losses[0] = losses[0] + 1;
        losses[1] = losses[1] + 1;
      }
      else if (rankB == 10) { // Capture The Flag 
        losses[1] = PIECES_PER_TEAM;
      }
      else if (rankA == 9 && rankB == 0) { // Spy kills Maarschalk
        defendingPiece.alive_piece = 0;
        endBox.state_box = FREE;

        selectionCounter = 0;

        losses[1] = losses[1] + 1;
      }

      else if (rankA > rankB) { // ATTACK LOSE //
        attackingPiece.alive_piece = 0;
        startBox.state_box = FREE;

        selectionCounter = 0;

        losses[0] = losses[0] + 1;
      } 
      else if (rankA < rankB) { // ATTACK WIN //
        defendingPiece.alive_piece = 0;
        endBox.state_box = FREE;

        selectionCounter = 0;

        losses[1] = losses[1] + 1;
      }

      // POST Pieces //
      piecesBlue[startBox.id_piece] = attackingPiece;
      piecesRed[endBox.id_piece]    = defendingPiece;

      teamCounter++;
    }
    else if (teamCounter == 1 && endBox.state_box == OCCUPIED_BLUE) { // Battle Time
      piece attackingPiece = piecesRed[startBox.id_piece];
      piece defendingPiece = piecesBlue[endBox.id_piece];

      int rankA = attackingPiece.rank_piece;
      int rankB = defendingPiece.rank_piece;

      // Determine Higer Rank //
      if (rankA == rankB) { // BOTH LOSE //
        attackingPiece.alive_piece = 0;
        startBox.state_box = FREE;

        defendingPiece.alive_piece = 0;
        endBox.state_box = FREE;

        selectionCounter = 0;

        losses[0] = losses[0] + 1;
        losses[1] = losses[1] + 1;
      }
      else if (rankB == 11 && rankA != 7) { // BOMB BLOWS U UP
        attackingPiece.alive_piece = 0;
        startBox.state_box = FREE;

        defendingPiece.alive_piece = 0;
        endBox.state_box = FREE;

        selectionCounter = 0;

        losses[0] = losses[0] + 1;
        losses[1] = losses[1] + 1;
      }
      else if (rankB == 10) { // Capture The Flag 
        losses[0] = PIECES_PER_TEAM;
      }
      else if (rankA == 9 && rankB == 0) { // Spy kills Maarschalk
        defendingPiece.alive_piece = 0;
        endBox.state_box = FREE;

        selectionCounter = 0;

        losses[0] = losses[0] + 1;
      }
      else if (rankA > rankB) { // ATTACK LOSE //
        attackingPiece.alive_piece = 0;
        startBox.state_box = FREE;

        selectionCounter = 0;

        losses[1] = losses[1] + 1;
      } 
      else if (rankA < rankB) { // ATTACK WIN //
        defendingPiece.alive_piece = 0;
        endBox.state_box = FREE;

        selectionCounter = 0;

        losses[0] = losses[0] + 1;
      }

      // POST Pieces //
      piecesRed[startBox.id_piece] = attackingPiece;
      piecesBlue[endBox.id_piece]    = defendingPiece;

      teamCounter--;
    }
    else { // If A Friendly Is There //
      selectionCounter = 0;
    }

    // Update The Boxes
    for (int a = 0; a < MAX_BOXES_Y + 1; a++) { // The Location For Y //
      for (int b = 0; b < MAX_BOXES_X + 1; b++) { // The Location For X //
        int index = ((MAX_BOXES_Y * a) + b);
        box theBox = boxes[index];

        if (theBox.id_box == startBox.id_box) boxes[index] = startBox;
        if (theBox.id_box == endBox.id_box) boxes[index]   = endBox;
      }
    }
  } else {
    selectionCounter = 0;
  }
}

void loadDisplay() {
  SDL_Rect display;
  display.x = 1100;
  display.y = 30;
  display.w = 350;
  display.h = 200;

  SDL_Texture *texture;

  if (teamCounter == 0) {
    SDL_SetRenderDrawColor(renderer, 0, 125, 255, 1);
    texture = load_texture(textBlue[selectedPiece]);
  }
  if (teamCounter == 1) {
    SDL_SetRenderDrawColor(renderer, 255, 125, 0, 1);
    texture = load_texture(textRed[selectedPiece]);
  }

  SDL_RenderFillRect(renderer, &display);
  blit(texture, 1275, 130, 1);
}

void loadTeamShower() {
  SDL_Rect teamShower;
  teamShower.x = 1000;
  teamShower.y = 400;
  teamShower.h = 100;
  teamShower.w = 100;
  if (teamCounter == 0) SDL_SetRenderDrawColor(renderer, 0, 125, 255, 1);
  if (teamCounter == 1) SDL_SetRenderDrawColor(renderer, 255, 125, 0, 1);

  SDL_RenderFillRect(renderer, &teamShower);
}

void loadSelectedDisplay(box *selectedBox) {
  SDL_Rect display;
  display.x = 1100;
  display.y = 30;
  display.w = 350;
  display.h = 200;

  SDL_Texture *texture;
  piece myPiece;

  if (selectedBox->state_box == OCCUPIED_BLUE) {
    SDL_SetRenderDrawColor(renderer, 0, 125, 255, 1);

    myPiece = piecesBlue[selectedBox->id_piece];
    texture = load_texture(textBlue[myPiece.id_piece]);
  }
  if (selectedBox->state_box == OCCUPIED_RED) {
    SDL_SetRenderDrawColor(renderer, 255, 125, 0, 1);

    myPiece = piecesBlue[selectedBox->id_piece];
    texture = load_texture(textRed[myPiece.id_piece]);
  }

  SDL_RenderFillRect(renderer, &display);
  blit(texture, 1275, 130, 1);
}

void loadPieces() {
  for (int a = 0; a < MAX_BOXES_Y + 1; a++) { // The Location For Y //
    for (int b = 0; b < MAX_BOXES_X + 1; b++) { // The Location For X //
      int index = ((MAX_BOXES_Y * a) + b);
      box theBox = boxes[index];

      // Its Either Occupied By Blue Or Red //
      if (theBox.state_box != FREE) {
        piece thePiece;
        SDL_Texture *theTexture;

        if (theBox.state_box == OCCUPIED_BLUE) {
          thePiece = piecesBlue[theBox.id_piece];
          if (thePiece.alive_piece == 1) {
            theTexture = load_texture(textBlue[thePiece.rank_piece]);
            blit(theTexture, theBox.x_box + 50, theBox.y_box + 50, 1);
          }
        }
        if (theBox.state_box == OCCUPIED_RED) {
          thePiece  = piecesRed[theBox.id_piece];
          if (thePiece.alive_piece == 1) {
            theTexture = load_texture(textRed[thePiece.rank_piece]);
            blit(theTexture, theBox.x_box + 50, theBox.y_box + 50, 1);
          }
        }
      }
    }
  }
}

void loadGrid() {
  for (int a = 0; a < MAX_BOXES_Y + 1; a++) { // The Location For Y //
    for (int b = 0; b < MAX_BOXES_X + 1; b++) { // The Location For X //
      // Calculate The Index For The Boxes Array //
      int index = ((MAX_BOXES_Y * a) + b);

      // Save The Box //
      box theBox = boxes[index];
    
      // For Showing The Box Start Location //
      blit(load_texture("gfx/reticle.png"), theBox.x_box, theBox.y_box, 1);
    }
  }
}

box getBox(box *selectedBox) {
  box theBox;

  // Get The Correct Boxes Out;
  for (int a = 0; a < MAX_BOXES_Y + 1; a++) { // The Location For Y //
    for (int b = 0; b < MAX_BOXES_X + 1; b++) { // The Location For X //
      int index = ((MAX_BOXES_Y * a) + b);
      box myBox = boxes[index];

      if (myBox.id_box == selectedBox->id_box) {
        theBox = myBox;
      }
    }
  }

  return theBox;
}
