#include "common.h"
#include "main.h"
#include "input.h"
#include "init.h"

void process_input(mouse *tha_mouse) {
  SDL_Event event;
	
  while (SDL_PollEvent(&event))	{		
    switch (event.type) {
      case SDL_QUIT:	
        proper_shutdown();
        exit(0);
	      break;
      case SDL_MOUSEBUTTONDOWN:
        if (gamePhase == 2) {
          initPiece();
        } else if (gamePhase == 3) {
          if (selectionCounter == 0) {
            initBoxA();
          } 
          else if (selectionCounter == 1) {
            initBoxB();
          }
        } 
        break;
      case SDL_KEYDOWN:
        switch (event.key.keysym.scancode) {
          case SDL_SCANCODE_ESCAPE:
            proper_shutdown();
            exit(0);
            break;
          case SDL_SCANCODE_F1:
            selectedPiece = 0;
            break;
          case SDL_SCANCODE_F2:
            selectedPiece = 1;
            break;          
          case SDL_SCANCODE_F3:
            selectedPiece = 2;
            break;          
          case SDL_SCANCODE_F4:
            selectedPiece = 3;
            break;          
          case SDL_SCANCODE_F5:
            selectedPiece = 4;
            break;          
          case SDL_SCANCODE_F6:
            selectedPiece = 5;
            break;          
          case SDL_SCANCODE_F7:
            selectedPiece = 6;
            break;          
          case SDL_SCANCODE_F8:
            selectedPiece = 7;
            break;          
          case SDL_SCANCODE_F9:
            selectedPiece = 8;
            break;          
          case SDL_SCANCODE_F10:
            selectedPiece = 9;
            break;          
          case SDL_SCANCODE_F11:
            selectedPiece = 10;
            break;          
          case SDL_SCANCODE_F12:
            selectedPiece = 11;
            break;          
          default:
            break;
          }

	      break;	
      default:
	      break;		
    }
  }

  SDL_GetMouseState(&tha_mouse->x, &tha_mouse->y);
}

void proper_shutdown(void) {
  SDL_DestroyRenderer(renderer);
  SDL_DestroyWindow(window);
  SDL_Quit();
}

