#ifndef INIT_H
#define INIT_H

void initSDL(int argc, char *argv[]); // For All Boot-up Stuff //
void initGrid(); // Make The Grid //
void initPiece();
void initBoxA();
void initBoxB();

#endif