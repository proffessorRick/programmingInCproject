#ifndef RENDER_H
#define RENDER_H

void blit(SDL_Texture *txtr, int x, int y, int center); // For Image Rendering //

SDL_Texture *load_texture(char *filename); // For Making Images Textures // 

#endif