#include "common.h"
#include "main.h"
#include "init.h"

void initBoxA() {
  box theBox;

  // Get The Box //
  for (int a = 0; a < MAX_BOXES_Y; a++) {
    for (int b = 0; b < MAX_BOXES_X; b++) {
      int currentIndex = ((MAX_BOXES_Y * a) + b);

      if (tha_now_box.id_box == boxes[currentIndex].id_box) {
        theBox = boxes[currentIndex];
      }
    }
  }

  selectionCounter = 1;

  // Set It To SelectedBoxA
  selectedBoxA = theBox;
}

void initBoxB() {
  box theBox;

  // Get The Box //
  for (int a = 0; a < MAX_BOXES_Y; a++) {
    for (int b = 0; b < MAX_BOXES_X; b++) {
      int currentIndex = ((MAX_BOXES_Y * a) + b);

      if (tha_now_box.id_box == boxes[currentIndex].id_box) {
        theBox = boxes[currentIndex];
      }
    }
  }
  selectionCounter = 2;

  // Set It To SelectedBoxA
  selectedBoxB = theBox;
}

void initGrid() {
  // Make All Boxes For The Game //
  for (int a = 0; a < MAX_BOXES_Y + 1; a++) { // The Location For Y //
    for (int b = 0; b < MAX_BOXES_X + 1; b++) { // The Location For X //
      // Calculate The Index For The Boxes Array //
      int index = ((MAX_BOXES_Y * a) + b);

      // Make A New Box And Set All Values For box //
      box newBox;
      newBox.id_box    = index;
      newBox.id_piece  = 200;
      newBox.x_box     = (b * 100) + 30;
      newBox.y_box     = (a * 100) + 30;
      newBox.state_box = FREE;

      // Save The Box //
      boxes[index] = newBox; 
    }
  }
}

void initSDL(int argc, char *argv[]) {
  (void)argc;
  (void)argv;

  srand((uint8_t)time(0));

  // All Security Checks //
  unsigned int window_flags = 0;
  unsigned int renderer_flags = SDL_RENDERER_ACCELERATED;
  if (SDL_Init(SDL_INIT_VIDEO) < 0) exit(1);
  window = SDL_CreateWindow("Stratego", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, window_flags);
  if (window == NULL) exit(1);	
  renderer = SDL_CreateRenderer(window, -1, renderer_flags);
  if (renderer == NULL) exit(1);	
 
  // This Is For Debugging Only!!!!!!!!!!!!!!!!!!!! //
  SDL_SetRenderDrawColor(renderer, 120, 144, 156, 255);
  SDL_RenderClear(renderer);
  
  // Load All Textures //
  IMG_Init(IMG_INIT_PNG);
}

void initPiece() {
  box theBox;
  int index, goAhead;

  // Get The Box //
  for (int a = 0; a < MAX_BOXES_Y; a++) {
    for (int b = 0; b < MAX_BOXES_X; b++) {
      int currentIndex = ((MAX_BOXES_Y * a) + b);

      if (tha_now_box.id_box == boxes[currentIndex].id_box) {
        theBox = boxes[currentIndex];
        index = currentIndex;
      }
    }
  }

  // For Team Blue It Must Be In The First 4 Boxes And It Should Be Empty //
  // For Team Red It Must Be In The Last 4 Boxes And It Should Be Empty //
  if ((teamCounter == 0 && theBox.y_box <= 330 && theBox.state_box == FREE) || 
      (teamCounter == 1 && theBox.y_box >= 630 && theBox.state_box == FREE)) {
    goAhead = 1;
  } 
  else { 
    goAhead = 0; 
  }

  if (goAhead == 1) {
    // Make A New Piece And Set It Values //
    piece newPiece;

    newPiece.id_box      = theBox.id_box;
    newPiece.id_piece    = pieceCounter;
    newPiece.rank_piece  = selectedPiece;
    newPiece.alive_piece = 1;
    newPiece.team_piece  = teamCounter;

    // Set The Box //
    if (teamCounter == 0) {
      theBox.state_box = OCCUPIED_BLUE;
      theBox.id_piece  = pieceCounter;

      // Post The Piece //
      piecesBlue[pieceCounter] = newPiece;
    } 
    else if (teamCounter == 1) {
      theBox.state_box = OCCUPIED_RED;
      theBox.id_piece  = pieceCounter;

      // Post The Piece //
      piecesRed[pieceCounter] = newPiece;
    }

    // Post The Box //
    boxes[index] = theBox;
  }
}
